import os,sys
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
sys.path.insert(0,'/mnt/data/EXP018_cause_analysis');sys.path.insert(0,'/mnt/data/exp018_3method_evaluation')
import numpy as np,pandas as pd,joblib
from scipy.ndimage import gaussian_filter
from sklearn.metrics.pairwise import cosine_similarity
from scipy.ndimage import binary_fill_holes,label
from evaluate_transforms import com
from pathlib import Path
D=Path('/mnt/data/shortcut_7to9_study')
with np.load('/mnt/data/handwritten_0-9_A-F_28x28_grayscale(2).npz') as z:nx=z['X'];ny=z['y'];src=z['source_image']
kept=np.zeros(len(ny),bool);kept[np.load('/mnt/data/EXP018_품질판정반영_438장/EXP018_user_screened_438.npz')['original_index']]=True
Xnew=com(nx).reshape(-1,28,28)
xx=[];yy=[]
for w in [41,42,43,44]:
 z=np.load(f'/mnt/data/exp018_3method_evaluation/official_github/ml26_{w}.npz');xx.append(z['img']);yy.append(z['label_id'])
xx=np.concatenate(xx);yy=np.concatenate(yy);xoff=com(xx).reshape(-1,28,28)
models=[joblib.load(f'/mnt/data/EXP018_cause_analysis/models/final/seed{i}.joblib') for i in (42,43,44)]
pre=np.stack([m.predict_proba(xoff.reshape(-1,784)) for m in models]).argmax(-1)
pool={k:np.where((yy==k)&(pre==k).all(axis=0))[0] for k in (7,9)}
items=[('new2',i,ny[i],Xnew[i]) for i in np.where(kept&(src==2)&np.isin(ny,[7,9]))[0]]
items += [('newother',i,ny[i],Xnew[i]) for i in np.where(kept&(src!=2)&np.isin(ny,[7,9]))[0]]
items += [('official',i,yy[i],xoff[i]) for i in np.where(np.isin(yy,[7,9]))[0]]
a=np.stack([im for *_,im in items]);N=len(a)
proba=np.stack([m.predict_proba(a.reshape(-1,784)) for m in models]);p=proba.argmax(-1)
labels=np.array([cl for _,__,cl,im in items]);ds=np.array([k for k,_,cl,im in items]);ixs=np.array([j for _,j,cl,im in items]);gY,gX=np.mgrid[0:28,0:28]
def region_mask(im,zone):
 yy,xx=np.nonzero(im>=32);y0,y1=yy.min(),yy.max();fy=(gY-y0)/max(1,y1-y0)
 z=(fy<=.35) if zone=='top35' else ((fy>.6)&(fy<=1.01))
 return gaussian_filter(z.astype('float32'),sigma=.65)
def topo(im):
 m=im>=96;_,h=label(binary_fill_holes(m)&~m);_,c=label(m);return h,c
orig_top=[topo(im) for im in a]
records=[]
for zone in ['top35','bottom']:
 masks=np.array([region_mask(im,zone) for im in a])
 for dc in (7,9):
  ids=pool[dc]
  sims=cosine_similarity(a.reshape(N,-1),xoff[ids].reshape(len(ids),-1));best=ids[sims.argmax(1)]
  b=np.zeros_like(a)
  for i in range(N):
   donor=xoff[best[i]].copy(); mask=masks[i]; orig=a[i]
   # match total brightness IN edited zone, do not increase pixel mass globally
   donor_mass=float((donor*mask).sum());orig_mass=float((orig*mask).sum())
   donor=np.clip(donor*(orig_mass/max(donor_mass,1)),0,255)
   # no saturation if donor ratio small; bounded after clip
   b[i]=np.clip((1-mask)*orig+mask*donor,0,255)
  preserved=np.array([topo(im)==old for im,old in zip(b,orig_top)])
  delta_mass=(b.sum((1,2))/a.sum((1,2))-1)
  c=com(b)
  probs=np.stack([m.predict_proba(c) for m in models]);pred=probs.argmax(-1)
  for j in range(N):
   records.append(dict(dataset=ds[j],index=int(ixs[j]),truth=int(labels[j]),region=zone,donor_class=dc,topology_preserved=bool(preserved[j]),
             donor_original_index=int(best[j]),mass_ratio=float(b[j].sum()/a[j].sum()),original_correct=int((p[:,j]==labels[j]).sum()),new_correct=int((pred[:,j]==labels[j]).sum()),orig_other=int((p[:,j]==(9 if labels[j]==7 else 7)).sum()),new_other=int((pred[:,j]==(9 if labels[j]==7 else 7)).sum()),
             delta_margin_log9_over7=float(np.mean(np.log(np.clip(probs[:,j,9],1e-30,1)/np.clip(probs[:,j,7],1e-30,1))-np.log(np.clip(proba[:,j,9],1e-30,1)/np.clip(proba[:,j,7],1e-30,1))))))
R=pd.DataFrame(records);R.to_csv(D/'phase6_massmatched_individual.csv',index=False)
S=R.groupby(['dataset','truth','region','donor_class']).agg(n=('index','size'),mean_mass_ratio=('mass_ratio','mean'),topology_frac=('topology_preserved','mean'),original_correct=('original_correct','sum'),new_correct=('new_correct','sum'),orig_to_other=('orig_other','sum'),new_to_other=('new_other','sum'),mean_delta_logodds=('delta_margin_log9_over7','mean')).reset_index()
S.to_csv(D/'phase6_massmatched_summary.csv',index=False)
print(S.round(3).to_string(index=False))
