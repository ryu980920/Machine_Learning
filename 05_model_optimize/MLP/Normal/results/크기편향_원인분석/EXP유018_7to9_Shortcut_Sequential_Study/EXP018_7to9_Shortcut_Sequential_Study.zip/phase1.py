import os,sys,json,hashlib
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
sys.path.insert(0,'/mnt/data/EXP018_cause_analysis')
sys.path.insert(0,'/mnt/data/exp018_3method_evaluation')
import numpy as np,pandas as pd,joblib
from pathlib import Path
from scipy.ndimage import binary_fill_holes
from scipy.stats import mannwhitneyu,spearmanr
from evaluate_transforms import com
D=Path('/mnt/data/shortcut_7to9_study'); D.mkdir(exist_ok=True)
models={k:{seed:joblib.load(f'/mnt/data/EXP018_cause_analysis/models/{k}/seed{seed}.joblib') for seed in (42,43,44)} for k in ('80-14','final')}
# New 480 images with screen mask
p='/mnt/data/handwritten_0-9_A-F_28x28_grayscale(2).npz'
with np.load(p) as z: N=z['X'];ny=z['y'];ns=z['source_image']
z=np.load('/mnt/data/EXP018_품질판정반영_438장/EXP018_user_screened_438.npz')
mask=np.zeros(480,dtype=bool); mask[z['original_index']]=True
assert len(mask.nonzero()[0])==438
W=[];L=[]
for w in (41,42,43,44):
 path=f'/mnt/data/exp018_3method_evaluation/official_github/ml26_{w}.npz';z=np.load(path)
 W.append(z['img']);L.append(z['label_id']);
assert sum(len(a) for a in W)==2560
Xhm=np.concatenate(W); yhm=np.concatenate(L);wid=np.repeat([41,42,43,44],640)
Xh=com(Xhm);Xn=com(N)
assert Xh.shape==(2560,784) and Xn.shape==(480,784)

# MLP posterior by version, baseline
source={"handmade2560":(Xhm,yhm,np.ones(2560,bool),wid,Xh),"new438":(N,ny,mask,ns,Xn)}
rows=[];prob_rows=[]
for name,(xx,yy,ok,ss,xc) in source.items():
 for variant in models:
  for seed,m in models[variant].items():
   q=m.predict_proba(xc);pred=q.argmax(1)
   for label in (7,9):
    for group in ["all",*sorted(set(ss))]:
     ix=ok&(yy==label)&(np.ones(len(ss),bool) if group=="all" else ss==group)
     if not ix.any():continue
     rows.append(dict(dataset=name,model=variant,seed=seed,group=str(group),truth=label,n=ix.sum(),correct=(pred[ix]==label).sum(),to_other=(pred[ix]==(9 if label==7 else 7)).sum(),margin_logp9_p7=np.log(np.maximum(q[ix,9],1e-200)/np.maximum(q[ix,7],1e-200)).mean()))
   if variant=='final' and yy is not None:
    chosen=np.flatnonzero(ok & np.isin(yy,[7,9]))
    for i in chosen:
     prob_rows.append(dict(dataset=name,seed=seed,idx=i,group=ss[i],truth=yy[i],pred=pred[i],p7=q[i,7],p9=q[i,9],log9over7=float(np.log(max(q[i,9],1e-150)/max(q[i,7],1e-150)))))
pd.DataFrame(rows).to_csv(D/'phase1_model7vs9_baselines.csv',index=False)
pd.DataFrame(prob_rows).to_csv(D/'phase1_individual7vs9_probs.csv',index=False)
print('BASELINES')
print(pd.DataFrame(rows).groupby(['dataset','model','group','truth'])[['n','correct','to_other']].mean().to_string(),flush=True)

# simple geometry on post-Com pixels with thresholds
Y,XX=np.mgrid[0:28,0:28]
def feat(img):
 a=img.reshape(28,28).astype(float); fg=a>=32
 ys,xs=np.nonzero(fg)
 if len(ys)==0:return {}
 x0,x1=xs.min(),xs.max();y0,y1=ys.min(),ys.max();w=x1-x0+1;h=y1-y0+1
 z=np.where(fg,a,0)
 normalized_y=(Y-y0)/max(h-1,1)
 normalized_x=(XX-x0)/max(w-1,1)
 bands=[(0,.35),(.35,.6),(.6,1.01)]
 feat=dict(width=w,height=h,aspect=w/h,mass=a.sum(),foreground_pixels=fg.sum(),mean_stroke_intensity=z.sum()/fg.sum())
 for j,(lo,hi) in enumerate(bands):
  m=fg&(normalized_y>=lo)&(normalized_y<hi)
  feat[f'band{j}_mass_frac']=z[m].sum()/max(z.sum(),1)
  feat[f'band{j}_centroid_x']=np.average(normalized_x[m],weights=a[m]) if m.any() else np.nan
  feat[f'band{j}_left_mass_frac']=z[m&(normalized_x<.5)].sum()/max(z[m].sum(),1)
  feat[f'band{j}_right_mass_frac']=z[m&(normalized_x>=.5)].sum()/max(z[m].sum(),1)
 # rowwise lower centerline slope, difference in x normalized by vertical extent
 row_x=[];row_y=[]
 for y in range(28):
  m=fg[y,:]&(normalized_y[y,:]>=.4)
  if m.any():row_y.append(float((y-y0)/max(h-1,1)));row_x.append(float(np.average(np.arange(28)[m],weights=a[y,m])))
 feat['lower_slope_dx_dy']=(np.polyfit(row_y,row_x,1)[0]/max(w-1,1)*max(h-1,1)) if len(row_y)>2 else np.nan
 # Weighted slope in absolute pixels dx/dy: 7 often slopes left and 9 near vertical
 feat['lower_slope_px']=(np.polyfit(row_y,row_x,1)[0]/max(h-1,1)) if len(row_y)>2 else np.nan
 yy=int(y0+round(.42*(h-1)));row=fg[yy];cent=np.average(np.arange(28)[row],weights=a[yy,row]) if row.any() else np.nan
 feat['upper_mid_x']=cent
 feat['n_hole_pixels']=int((binary_fill_holes(a>=96)&(a<96)).sum())
 return feat
R=[]
for name,(xx,yy,ok,ss,xc) in source.items():
 q=np.stack([models['final'][s].predict_proba(xc) for s in [42,43,44]])
 pr=q.argmax(-1)
 for i in np.flatnonzero(ok & np.isin(yy,[7,9])):
  d=feat(xc[i]);d.update(dataset=name,idx=i,group=ss[i],true=yy[i],three_preds=''.join('0123456789ABCDEF'[int(z)] for z in pr[:,i]),n_to9=int((pr[:,i]==9).sum()),mean_margin=float(np.log(np.clip(q[:,i,9],1e-10,1)/np.clip(q[:,i,7],1e-10,1)).mean()))
  R.append(d)
f=pd.DataFrame(R);f.to_csv(D/'phase1_7vs9_geometry.csv',index=False)
print('FEATURE SUMMARY')
print(f.groupby(['dataset','group','true'])[['width','height','aspect','mass','band0_mass_frac','band1_mass_frac','band2_mass_frac','band0_centroid_x','band1_centroid_x','band2_centroid_x','lower_slope_px','n_hole_pixels']].median().round(3).to_string(),flush=True)
print('WITHIN group2 true7')
print(f[(f.dataset=='new438')&(f.group==2)&(f.true==7)][['idx','three_preds','width','height','band0_centroid_x','band1_centroid_x','band2_centroid_x','lower_slope_px','n_hole_pixels']].round(3).to_string(index=False),flush=True)
