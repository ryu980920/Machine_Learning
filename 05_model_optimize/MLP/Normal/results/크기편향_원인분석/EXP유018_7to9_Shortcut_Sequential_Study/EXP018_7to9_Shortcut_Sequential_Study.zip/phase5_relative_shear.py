import os,sys
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
sys.path.insert(0,'/mnt/data/EXP018_cause_analysis');sys.path.insert(0,'/mnt/data/exp018_3method_evaluation')
import numpy as np,pandas as pd,joblib
from pathlib import Path
from scipy.ndimage import map_coordinates,binary_fill_holes,label
from evaluate_transforms import com
D=Path('/mnt/data/shortcut_7to9_study');D.mkdir(exist_ok=True)
with np.load('/mnt/data/handwritten_0-9_A-F_28x28_grayscale(2).npz') as z:N=z['X'];ny=z['y'];src=z['source_image']
kept=np.zeros(len(ny),bool);kept[np.load('/mnt/data/EXP018_품질판정반영_438장/EXP018_user_screened_438.npz')['original_index']]=True
xx=[];yy=[]
for w in [41,42,43,44]:
 z=np.load(f'/mnt/data/exp018_3method_evaluation/official_github/ml26_{w}.npz');xx.append(z['img']);yy.append(z['label_id'])
XX=np.concatenate(xx);YY=np.concatenate(yy)
models={s:joblib.load(f'/mnt/data/EXP018_cause_analysis/models/final/seed{s}.joblib') for s in (42,43,44)}
gY,gX=np.mgrid[0:28,0:28].astype('float32')
def shear(im,strength):
 y,x=np.where(im>=32);y0,y1=y.min(),y.max()
 # upper moves +strength/2 to right, bottom moves -strength/2 to left => relative tail leftward with strength positive
 fy=(gY-y0)/max(1,y1-y0)
 dx=strength*(.5-fy)
 new=map_coordinates(im,[gY,gX-dx],order=1,mode='constant',cval=0,prefilter=False)
 if new.sum()>1:new=np.clip(new*(im.sum()/new.sum()),0,255)
 return new
def get_topology(im):
 x=im>=96;holes=binary_fill_holes(x)&~x;_,h=label(holes);_,c=label(x)
 return h,c
summary=[];individual=[]
for ds,raw,labels,mask,groups in [('official2560',XX,YY,np.ones(len(YY),bool),np.repeat([41,42,43,44],640)),('new438',N,ny,kept,src)]:
 raw=raw[mask];y=labels[mask];g=groups[mask];baseline=com(raw).reshape(-1,28,28)
 base_prob=np.stack([m.predict_proba(baseline.reshape(-1,784)) for m in models.values()]);bp=base_prob.argmax(-1)
 if ds=='official2560': assert [sum(bp[i]==y) for i in range(3)]==[2363,2361,2347], [sum(bp[i]==y) for i in range(3)]
 else: assert [sum(bp[i]==y) for i in range(3)]==[381,386,388]
 focus=np.where(np.isin(y,[7,9]))[0];top0={i:get_topology(baseline[i]) for i in focus}
 for strength in (-2,-1,0,1,2):
  warped=np.array([shear(im,strength) for im in baseline],dtype='float32') if strength!=0 else baseline
  mt=np.array([get_topology(warped[i])==top0[i] for i in focus]);valid=np.zeros(len(y),bool);valid[focus]=mt
  # model always receives CoM from raw warped; no class-specific branch
  x=com(warped)
  probs=np.stack([m.predict_proba(x) for m in models.values()]); pred=probs.argmax(-1)
  for gg in ['all','digits','letters','7','9','group2_7','group2_9']:
   subset=(np.ones(len(y),bool) if gg=='all' else y<10 if gg=='digits' else y>=10 if gg=='letters' else y==7 if gg=='7' else y==9 if gg=='9' else (g==2)&(y==7) if gg=='group2_7' else (g==2)&(y==9))
   if ds=='official2560' and gg.startswith('group2'):continue
   if subset.sum()==0:continue
   for topology_cond in ['all','topology_preserved']:
    if topology_cond=='topology_preserved':
     if gg not in ('7','9','group2_7','group2_9'):continue
     subset=subset &valid
    if not subset.sum():continue
    labels_count=int(subset.sum())
    summary.append(dict(dataset=ds,strength=strength,group=gg,subset=topology_cond,n=labels_count,correct=int((pred[:,subset]==y[subset]).sum()),accuracy=float(np.mean(pred[:,subset]==y[subset])),wrong7_to9=int((pred[:,subset]==9).sum()) if gg in ('7','group2_7') else -1,wrong9_to7=int((pred[:,subset]==7).sum()) if gg in ('9','group2_9') else -1,
      mean_log9over7=float(np.mean(np.log(np.clip(probs[:,subset,9],1e-35,1)/np.clip(probs[:,subset,7],1e-35,1))))))
    if topology_cond=='topology_preserved':subset=(np.ones(len(y),bool) if gg=='all' else y<10 if gg=='digits' else y>=10 if gg=='letters' else y==7 if gg=='7' else y==9 if gg=='9' else (g==2)&(y==7) if gg=='group2_7' else (g==2)&(y==9))
  for i in focus:
   if (ds=='new438' and g[i]!=2):continue
   individual.append(dict(dataset=ds,index=int(i),group=int(g[i]),truth=int(y[i]),strength=strength,topology_preserved=bool(valid[i]),correct_3seeds=int((pred[:,i]==y[i]).sum()),wrong_to_other_3seeds=int((pred[:,i]==(9 if y[i]==7 else 7)).sum()),mean_margin_log9_over7=float(np.log(np.clip(probs[:,i,9],1e-35,1)/np.clip(probs[:,i,7],1e-35,1)).mean())))
S=pd.DataFrame(summary);S.to_csv(D/'phase5_relative_shear_accuracy.csv',index=False)
I=pd.DataFrame(individual);I.to_csv(D/'phase5_relative_shear_individual.csv',index=False)
print(S[((S.dataset=='official2560')&(S.group.isin(['all','7','9']))) | ((S.dataset=='new438')&(S.group.isin(['all','group2_7','group2_9'])))].round(4).to_string(index=False))
