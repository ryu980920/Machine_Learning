import os,sys
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
sys.path.insert(0,'/mnt/data/EXP018_cause_analysis');sys.path.insert(0,'/mnt/data/exp018_3method_evaluation')
import numpy as np,pandas as pd,joblib
from evaluate_transforms import com
from pathlib import Path
D=Path('/mnt/data/shortcut_7to9_study')
with np.load('/mnt/data/handwritten_0-9_A-F_28x28_grayscale(2).npz') as z:X=z['X'];Y=z['y'];grp=z['source_image']
indices=[167,183,215,231,247,263,279,295,311]
inputs=com(X[indices]);res=[]
for ix,inp in zip(indices,inputs):
 for seed in (42,43,44):
  for model in ('80-14','final'):
   m=joblib.load(f'/mnt/data/EXP018_cause_analysis/models/{model}/seed{seed}.joblib')
   p=m.predict_proba(inp[None])[0]
   res.append(dict(idx=ix,seed=seed,model=model,p7=float(p[7]),p9=float(p[9]),margin_log9over7=float(np.log(max(p[9],1e-50)/max(p[7],1e-50))),pred='0123456789ABCDEF'[p.argmax()]))
R=pd.DataFrame(res);R.to_csv(D/'phase8_old_vs_new_model_per_image.csv',index=False)
print(R.groupby('model').agg({'p7':'mean','p9':'mean','margin_log9over7':['mean','median']}).round(3).to_string())
print(R.pivot_table(index='idx',columns=['model','seed'],values='pred',aggfunc='first').to_string())
