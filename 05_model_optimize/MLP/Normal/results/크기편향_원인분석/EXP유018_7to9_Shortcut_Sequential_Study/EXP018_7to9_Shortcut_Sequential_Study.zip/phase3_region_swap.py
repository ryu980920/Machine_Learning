import os,sys
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
sys.path.insert(0,'/mnt/data/EXP018_cause_analysis');sys.path.insert(0,'/mnt/data/exp018_3method_evaluation')
import numpy as np,pandas as pd,joblib,matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter,gaussian_filter1d
from sklearn.metrics.pairwise import cosine_similarity
from evaluate_transforms import com
from pathlib import Path
D=Path('/mnt/data/shortcut_7to9_study')
with np.load('/mnt/data/handwritten_0-9_A-F_28x28_grayscale(2).npz') as z:raw=z['X'];ny=z['y'];src=z['source_image']
kept=np.zeros(len(ny),bool);kept[np.load('/mnt/data/EXP018_품질판정반영_438장/EXP018_user_screened_438.npz')['original_index']]=True
Xnew=com(raw).reshape(-1,28,28)
models=[joblib.load(f'/mnt/data/EXP018_cause_analysis/models/final/seed{i}.joblib') for i in (42,43,44)]
xx=[];yy=[]
for w in [41,42,43,44]:
 z=np.load(f'/mnt/data/exp018_3method_evaluation/official_github/ml26_{w}.npz');xx.append(z['img']);yy.append(z['label_id'])
xx=np.concatenate(xx);yy=np.concatenate(yy);Xoff=com(xx).reshape(-1,28,28)
Poff=np.stack([m.predict_proba(Xoff.reshape(-1,784)) for m in models]);preds=Poff.argmax(-1)
# Donors with unambiguous 3seed true label. Same class 7 or 9.
pool={k:np.where((yy==k)&(preds==k).all(axis=0))[0] for k in (7,9)}
print('donors', {k:len(v) for k,v in pool.items()})
targets=np.where(kept&(src==2)&np.isin(ny,[7,9]))[0]
others=np.where(kept&(src==1)&np.isin(ny,[7,9]))[0]
# official controls include narrow 7 and 9 from each writer; cap 80 total
controls=np.r_[np.where(yy==7)[0][::4],np.where(yy==9)[0][::4]]
# 4writer 160 per class -> 40 per class
assert len(controls)==80
items=[('new2',i,ny[i],Xnew[i]) for i in targets]+[('new1',i,ny[i],Xnew[i]) for i in others]+[('official',i,yy[i],Xoff[i]) for i in controls]
# donor match via raw-pixel cosine after CoM
ims=np.stack([x for *_,x in items]).astype('float32')
match={}
for donor_class,ids in pool.items():
 a=ims.reshape(len(items),-1);d=Xoff[ids].reshape(len(ids),-1).astype('float32')
 sim=cosine_similarity(a,d)
 for j,(ds,ix,cl,_im) in enumerate(items):
  if ds=='official' and donor_class==cl and ix in ids:sim[j,np.where(ids==ix)[0][0]]=-1
  match[j,donor_class]=(int(ids[np.argmax(sim[j])]),float(sim[j].max()))

def mask_relative(im,region):
 y,x=np.where(im>=32);top,bottom=y.min(),y.max();left,right=x.min(),x.max()
 yy,xx=np.mgrid[0:28,0:28]
 fy=(yy-top)/max(bottom-top,1)
 if region=='top35':g=(fy<=.35).astype('float32')
 elif region=='top60':g=(fy<=.6).astype('float32')
 elif region=='mid':g=((fy>.35)&(fy<=.6)).astype('float32')
 elif region=='bottom':g=(fy>.6).astype('float32')
 elif region=='full':g=np.ones_like(im)
 else:raise ValueError(region)
 g=gaussian_filter(g,sigma=.65)
 return np.clip(g,0,1)
records=[];viz={}
for region in ('top35','top60','mid','bottom','full'):
 for dc in (7,9):
  for alpha in (.60,1.00):
   transformed=[]
   for j,(dataset,idx,cl,im) in enumerate(items):
    donor=Xoff[match[j,dc][0]]
    g=mask_relative(im,region)*alpha
    t=np.clip(im*(1-g)+donor*g,0,255)
    transformed.append(t)
   transformed=np.stack(transformed)
   recentered=com(transformed)
   proba=np.stack([m.predict_proba(recentered) for m in models])
   pred=proba.argmax(-1)
   old=np.stack([m.predict_proba(ims.reshape(-1,784)) for m in models]);pold=old.argmax(-1)
   for j,(dataset,idx,cl,im) in enumerate(items):
    rec=dict(dataset=dataset,index=int(idx),truth=int(cl),region=region,donor_class=dc,donor_idx=match[j,dc][0],donor_similarity=match[j,dc][1],alpha=alpha,
             original_correct=int((pold[:,j]==cl).sum()),new_correct=int((pred[:,j]==cl).sum()),original_7to9=int((pold[:,j]==9).sum()) if cl==7 else -1,new_7to9=int((pred[:,j]==9).sum()) if cl==7 else -1,
             original_9to7=int((pold[:,j]==7).sum()) if cl==9 else -1,new_9to7=int((pred[:,j]==7).sum()) if cl==9 else -1,
             original_margin=float(np.mean(np.log(np.maximum(old[:,j,9],1e-100)/np.maximum(old[:,j,7],1e-100)))),
             new_margin=float(np.mean(np.log(np.maximum(proba[:,j,9],1e-100)/np.maximum(proba[:,j,7],1e-100)))) )
    records.append(rec)
   if dc==7 and alpha==1.0 and region in ('top35','top60','bottom','full'):
    viz[region]=transformed.copy()
A=pd.DataFrame(records); A.to_csv(D/'phase3_region_swap_individual.csv',index=False)
B=A.groupby(['dataset','truth','region','donor_class','alpha']).agg(n=('index','nunique'),old_correct=('original_correct','sum'),new_correct=('new_correct','sum'),old_7to9=('original_7to9','sum'),new_7to9=('new_7to9','sum'),old_9to7=('original_9to7','sum'),new_9to7=('new_9to7','sum'),median_logodds_change=('new_margin',lambda v:0)).reset_index()
B['median_logodds_change']=A.groupby(['dataset','truth','region','donor_class','alpha']).apply(lambda s:(s.new_margin-s.original_margin).median(),include_groups=False).values
B.to_csv(D/'phase3_region_swap_summary.csv',index=False)
print('New2 target TRUE7 and TRUE9')
print(B[(B.dataset=='new2')&(B.alpha==1.0)].round(2).to_string(index=False),flush=True)
# visualize 5 cases: fixed top band with 7 donor vs base and bottom
keep_inds=[167,183,215,247,263,279,295,169,185]
fig,axes=plt.subplots(len(keep_inds),5,figsize=(8,18))
for r,idx in enumerate(keep_inds):
 j=next(j for j,(ds,i,cl,im) in enumerate(items) if ds=='new2' and i==idx)
 for col,im in enumerate([ims[j],viz['top35'][j],viz['top60'][j],viz['bottom'][j],viz['full'][j]]):
  axes[r,col].imshow(im,vmin=0,vmax=255,cmap='gray',interpolation='nearest')
  axes[r,col].axis('off')
  if col==0:axes[r,col].set_ylabel(f'#{idx}',rotation=0,labelpad=15)
for col,t in enumerate(['Original','Top35 7 donor','Top60 7 donor','Bottom 7 donor','Full 7 donor']):axes[0,col].set_title(t,fontsize=9)
fig.tight_layout();fig.savefig(D/'phase3_region_patch_controls.png',dpi=115);plt.close(fig)
