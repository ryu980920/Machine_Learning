import os,sys
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
sys.path.insert(0,'/mnt/data/EXP018_cause_analysis');sys.path.insert(0,'/mnt/data/exp018_3method_evaluation')
import numpy as np,pandas as pd,joblib
from scipy.ndimage import binary_fill_holes
from evaluate_transforms import com
from pathlib import Path
D=Path('/mnt/data/shortcut_7to9_study')
with np.load('/mnt/data/handwritten_0-9_A-F_28x28_grayscale(2).npz') as z:Xnew=z['X'];Ynew=z['y'];src=z['source_image']
keep=np.zeros(len(Ynew),bool);keep[np.load('/mnt/data/EXP018_품질판정반영_438장/EXP018_user_screened_438.npz')['original_index']]=True
xs=[];ys=[]
for w in (41,42,43,44):
 z=np.load(f'/mnt/data/exp018_3method_evaluation/official_github/ml26_{w}.npz');xs.append(z['img']);ys.append(z['label_id'])
models=[joblib.load(f'/mnt/data/EXP018_cause_analysis/models/final/seed{s}.joblib') for s in (42,43,44)]
res=[]
for ds,x,y,g in [('official2560',np.concatenate(xs),np.concatenate(ys),np.repeat([41,42,43,44],640)),('new438',Xnew[keep],Ynew[keep],src[keep])]:
 x=com(x).reshape(-1,28,28)
 has_hole=np.array([((binary_fill_holes(im>=96)&~(im>=96)).sum()>=2) for im in x])
 for seed,m in zip((42,43,44),models):
  p=m.predict_proba(x.reshape(-1,784));baseline=p.argmax(1)
  modified=baseline.copy();modified[(baseline==9)&~has_hole]=7
  for s,mask in [('all',np.ones(len(y),bool)),('class7',y==7),('class9',y==9),('group2_7',(g==2)&(y==7)),('group2_9',(g==2)&(y==9))]:
   if not mask.any():continue
   res.append(dict(dataset=ds,seed=seed,group=s,n=mask.sum(),holes_true=int(has_hole[mask].sum()),old_correct=int((baseline[mask]==y[mask]).sum()),new_correct=int((modified[mask]==y[mask]).sum()),old_7to9=int((baseline[mask]==9).sum()) if s.endswith('7') else -1,new_7to9=int((modified[mask]==9).sum()) if s.endswith('7') else -1,old_9to7=int((baseline[mask]==7).sum()) if s.endswith('9') else -1,new_9to7=int((modified[mask]==7).sum()) if s.endswith('9') else -1))
R=pd.DataFrame(res);R.to_csv(D/'phase7_open_loop_heuristic_sanity.csv',index=False)
print(R.groupby(['dataset','group']).agg({'n':'mean','old_correct':'mean','new_correct':'mean','old_7to9':'mean','new_7to9':'mean','old_9to7':'mean','new_9to7':'mean'}).round(2).to_string())
