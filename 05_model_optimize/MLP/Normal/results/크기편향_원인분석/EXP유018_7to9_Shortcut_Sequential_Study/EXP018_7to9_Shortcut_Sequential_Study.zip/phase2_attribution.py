import os,sys
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
sys.path.insert(0,'/mnt/data/EXP018_cause_analysis');sys.path.insert(0,'/mnt/data/exp018_3method_evaluation')
import numpy as np, pandas as pd,joblib,matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
from evaluate_transforms import com
D=Path('/mnt/data/shortcut_7to9_study')
with np.load('/mnt/data/handwritten_0-9_A-F_28x28_grayscale(2).npz') as z:Xraw=z['X'];Y=z['y'];src=z['source_image']
z=np.load('/mnt/data/EXP018_품질판정반영_438장/EXP018_user_screened_438.npz');keep=np.zeros(len(Y),bool);keep[z['original_index']]=True
newX=com(Xraw).reshape(-1,28,28)
Xall=[];yall=[]
for wr in [41,42,43,44]:
 z=np.load(f'/mnt/data/exp018_3method_evaluation/official_github/ml26_{wr}.npz');Xall.append(z['img']);yall.append(z['label_id'])
Xall=np.concatenate(Xall);yall=np.concatenate(yall); hx=com(Xall).reshape(-1,28,28)
models=[joblib.load(f'/mnt/data/EXP018_cause_analysis/models/final/seed{i}.joblib').named_steps['model'] for i in (42,43,44)]
# Select image list deliberately: all grp2 7 and 9, grp1 7, official 7/9 stratified match by narrow width; exclude correct labels not known
inds=[i for i in range(len(Y)) if keep[i] and Y[i] in (7,9)]
sels=[('new',i,newX[i],int(Y[i]),int(src[i])) for i in inds]
# other writer 7/9 all for stats? expensive, sample balanced 40 per class from writers41..44
for cl in [7,9]:
 for wr in [41,42,43,44]:
  ids=np.flatnonzero((yall==cl)&(np.repeat([41,42,43,44],640)==wr))
  for i in ids[::4]:sels.append(('official',int(i),hx[i],int(cl),int(wr)))
print('selected',len(sels),flush=True)

def logits(model,x):
 xs=x.reshape(-1,784)/255.0
 a=xs
 for w,b in zip(model.coefs_,model.intercepts_):a=np.maximum(0,a@w+b) if w is not model.coefs_[-1] else a@w+b
 return a

def ig(model,images,steps=50):
 # image in 0-255 flatten, baseline0. integrate z9-z7 including input absences
 W1,W2,W3=model.coefs_;b1,b2,b3=model.intercepts_
 flat=images.reshape(-1,784).astype('float32')/255.
 inputs=flat
 sum_grad=np.zeros_like(inputs,dtype='float64')
 diff=W3[:,9]-W3[:,7]
 for s in range(steps):
  alpha=(s+.5)/steps
  z1=(inputs*alpha)@W1+b1
  a1=np.maximum(0,z1)
  z2=a1@W2+b2
  g2=np.broadcast_to(diff,(len(images),len(diff)))*(z2>0)
  g1=(g2@W2.T)*(z1>0)
  deriv=g1@W1.T
  sum_grad+=deriv
 at=inputs*sum_grad/steps
 out=logits(model,images)
 zero=logits(model,np.zeros_like(images))
 consistency=(out[:,9]-out[:,7])-(zero[:,9]-zero[:,7])-at.sum(axis=1)
 return at.reshape(-1,28,28),consistency

# chunks to avoid huge mem
arrays=np.array([v[2] for v in sels],dtype='float32')
ig_avg=np.zeros_like(arrays)
consistent=[]
for mod in models:
 xlist=[];cs=[]
 for start in range(0,len(sels),32):
  a,c=ig(mod,arrays[start:start+32],steps=60);xlist.append(a);cs.extend(c)
 ig_avg+=np.concatenate(xlist)/3
 consistent.extend(cs)
print('IG residual mae median p95',np.median(abs(np.array(consistent))),np.percentile(np.abs(np.array(consistent)),95),flush=True)
np.savez_compressed(D/'phase2_attributions.npz',attribution=ig_avg,images=arrays)
# measures: relative y positions row; upper,left etc
records=[]
for (dataset,i,img,y,grp),att in zip(sels,ig_avg):
 ys,xs=np.nonzero(img>=32);top,bottom=ys.min(),ys.max();left,right=xs.min(),xs.max()
 relative_y=(np.arange(28)[:,None]-top)/max(bottom-top,1)
 relative_x=(np.arange(28)[None,:]-left)/max(right-left,1)
 d={'dataset':dataset,'idx':i,'true':y,'group':grp,'all_9_evidence':float(att[att>0].sum()),'all_7_evidence':float(att[att<0].sum()),'total_ig':float(att.sum()),'max_abs_ig':float(np.abs(att).max())}
 for n,lo,hi in [('top',0,.35),('mid',.35,.60),('bottom',.6,1.01)]:
  m=(relative_y>=lo)&(relative_y<hi)
  a=att[m.repeat(28,axis=1)]
  d[f'{n}_ig_net']=float(a.sum());d[f'{n}_ig_9_positive']=float(a[a>0].sum());d[f'{n}_ig_7_negative']=float(a[a<0].sum())
 for n,lo,hi in [('left',0,.4),('center',.4,.7),('right',.7,1.01)]:
  m=(relative_x>=lo)&(relative_x<hi)
  a=att[np.repeat(m,28,axis=0)]
  d[f'{n}_ig_net']=float(a.sum())
 records.append(d)
out=pd.DataFrame(records)
# append preds
nprob=pd.read_csv(D/'phase1_individual7vs9_probs.csv')
nprob=nprob[nprob.dataset=='new438'].groupby('idx').agg({'pred':lambda c: ''.join('0123456789ABCDEF'[int(x)] for x in c),'log9over7':'mean'}).reset_index()
out.loc[out.dataset=='new','prediction_seeds']=out[out.dataset=='new'].idx.map(dict(zip(nprob.idx,nprob.pred)))
out.to_csv(D/'phase2_attributions_per_image.csv',index=False)
print('attribution summary:')
print(out.groupby(['dataset','group','true'])[['top_ig_net','mid_ig_net','bottom_ig_net','left_ig_net','center_ig_net','right_ig_net','total_ig']].median().round(2).to_string(),flush=True)
print('grp2 seven')
print(out[(out.dataset=='new')&(out.group==2)&(out.true==7)][['idx','prediction_seeds','top_ig_net','mid_ig_net','bottom_ig_net','total_ig']].round(2).to_string(index=False),flush=True)
# main visuals
idxs=[167,183,215,247,263,279,295,169,185,201]
fig,axes=plt.subplots(len(idxs),3,figsize=(7,21))
lim=max(abs(ig_avg[i]).max() for i,(ds,j,*rest) in enumerate(sels) if ds=='new' and j in idxs)
for row,i in enumerate(idxs):
 k=next(k for k,(ds,j,*rest) in enumerate(sels) if ds=='new' and j==i)
 im=arrays[k];a=ig_avg[k]
 axes[row,0].imshow(im,cmap='gray',vmin=0,vmax=255,interpolation='nearest')
 axes[row,1].imshow(a,cmap='RdBu_r',vmin=-lim,vmax=lim,interpolation='nearest')
 axes[row,2].imshow(a*(im>32),cmap='RdBu_r',vmin=-lim,vmax=lim,interpolation='nearest')
 for j in range(3):axes[row,j].set_xticks([]);axes[row,j].set_yticks([])
 axes[row,0].set_ylabel(f'#{i} {"7" if Y[i]==7 else "9"}',fontsize=9)
for j,t in enumerate(['CoM input','IG 9 (+red) / 7 (blue)','IG visible ink']):axes[0,j].set_title(t,fontsize=10)
plt.tight_layout();fig.savefig(D/'phase2_7to9_IG_examples.png',dpi=130);plt.close(fig)
