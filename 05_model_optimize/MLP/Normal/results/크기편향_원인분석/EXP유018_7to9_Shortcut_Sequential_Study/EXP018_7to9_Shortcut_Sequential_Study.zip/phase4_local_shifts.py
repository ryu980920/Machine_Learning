import os,sys
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
sys.path.insert(0,'/mnt/data/EXP018_cause_analysis');sys.path.insert(0,'/mnt/data/exp018_3method_evaluation')
import numpy as np,pandas as pd,joblib,matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.ndimage import map_coordinates,binary_fill_holes,label
from pathlib import Path
from evaluate_transforms import com
D=Path('/mnt/data/shortcut_7to9_study')
with np.load('/mnt/data/handwritten_0-9_A-F_28x28_grayscale(2).npz') as z:raw=z['X'];ny=z['y'];src=z['source_image']
kept=np.zeros(len(ny),bool);kept[np.load('/mnt/data/EXP018_품질판정반영_438장/EXP018_user_screened_438.npz')['original_index']]=True
Xnew=com(raw).reshape(-1,28,28)
xx=[];yy=[];grp=[]
for w in [41,42,43,44]:
 z=np.load(f'/mnt/data/exp018_3method_evaluation/official_github/ml26_{w}.npz');xx.append(z['img']);yy.append(z['label_id']);grp.extend([w]*640)
xx=np.concatenate(xx);yy=np.concatenate(yy);grp=np.array(grp);Xoff=com(xx).reshape(-1,28,28)
items=[('new'+str(src[i]),i,ny[i],Xnew[i]) for i in np.where(kept&np.isin(ny,[7,9]))[0]]
items += [('official'+str(grp[i]),i,yy[i],Xoff[i]) for i in np.where(np.isin(yy,[7,9]))[0]]
arr=np.array([x for *_,x in items],dtype='float32');N=len(arr)
models=[joblib.load(f'/mnt/data/EXP018_cause_analysis/models/final/seed{i}.joblib') for i in (42,43,44)]
origprobs=np.stack([m.predict_proba(arr.reshape(-1,784)) for m in models]);origpred=origprobs.argmax(-1)

xx_grid,yy_grid=np.meshgrid(np.arange(28,dtype='float32'),np.arange(28,dtype='float32'))
def warp(im,mode,dx):
 y,x=np.where(im>=32);top,bottom=y.min(),y.max()
 pos=(yy_grid-top)/max(bottom-top,1)
 if mode=='top':
  weight=np.clip((.55-pos)/.3,0,1)
 elif mode=='bottom':
  weight=np.clip((pos-.4)/.35,0,1)
 else:raise ValueError(mode)
 target_x=xx_grid-dx*weight
 new=map_coordinates(im,[yy_grid,target_x],order=1,mode='constant',cval=0,prefilter=False).astype('float32')
 if new.sum()>0:new=np.clip(new*(im.sum()/new.sum()),0,255)
 return new

def topology(img):
 m=img>=96
 holes=binary_fill_holes(m)&~m
 num_holes,n=label(holes)
 _,nc=label(m)
 return (int(n),int(nc))

prior_top=[topology(im) for im in arr]
records=[];summary=[]
for mode in ('top','bottom'):
 for dx in (-2,-1,1,2):
  transformed=np.array([warp(im,mode,dx) for im in arr]); after_top=[topology(im) for im in transformed]
  preserve=np.array([old==new for old,new in zip(prior_top,after_top)])
  transformed=com(transformed).reshape(-1,784)
  probs=np.stack([m.predict_proba(transformed) for m in models]);pr=probs.argmax(-1)
  for j,(ds,ix,cl,im) in enumerate(items):
   x=probs[:,j,:];b=origprobs[:,j,:]
   records.append(dict(dataset=ds,index=int(ix),true=int(cl),mode=mode,dx=dx,topology_preserved=int(preserve[j]),
     original_correct=int(np.sum(origpred[:,j]==cl)),new_correct=int(np.sum(pr[:,j]==cl)),
     original_to_other=int(np.sum(origpred[:,j]==(9 if cl==7 else 7))),new_to_other=int(np.sum(pr[:,j]==(9 if cl==7 else 7))),
     mean_margin_shift=float(np.mean(np.log(np.clip(x[:,9],1e-30,1)/np.clip(x[:,7],1e-30,1))-np.log(np.clip(b[:,9],1e-30,1)/np.clip(b[:,7],1e-30,1))))))
  A=pd.DataFrame(records)
  d=A[(A['mode']==mode)&(A['dx']==dx)]
  for family,cond in [('group2',d.dataset=='new2'),('newother',d.dataset.isin(['new1','new3'])),('official',d.dataset.str.startswith('official'))]:
   for cl in (7,9):
    subset=d[cond&(d.true==cl)&(d.topology_preserved==1)]
    summary.append(dict(dataset=family,truth=cl,mode=mode,dx=dx,n=len(subset),topology_preservation_pct=float(100*d[cond&(d.true==cl)].topology_preserved.mean()),
      original_correct=subset.original_correct.sum(),new_correct=subset.new_correct.sum(),original_to_other=subset.original_to_other.sum(),new_to_other=subset.new_to_other.sum(),mean_margin_shift=subset.mean_margin_shift.mean(),median_margin_shift=subset.mean_margin_shift.median()))
R=pd.DataFrame(records);S=pd.DataFrame(summary)
R.to_csv(D/'phase4_small_shift_individual.csv',index=False)
S.to_csv(D/'phase4_small_shift_summary.csv',index=False)
print(S.round(3).to_string(index=False),flush=True)
# visual cases
ixs=[167,183,215,247,263,279,295,169,185]
fig,ax=plt.subplots(len(ixs),5,figsize=(8,17))
for r,idx in enumerate(ixs):
 j=next(j for j,(ds,i,cl,im) in enumerate(items) if ds=='new2' and i==idx)
 for c,(mode,dx) in enumerate([('original',0),('top',-2),('top',2),('bottom',-2),('bottom',2)]):
  v=arr[j] if c==0 else warp(arr[j],mode,dx)
  ax[r,c].imshow(v,cmap='gray',vmin=0,vmax=255,interpolation='nearest');ax[r,c].axis('off')
  if c==0:ax[r,c].set_ylabel(f'#{idx}',rotation=0,labelpad=13)
for c,t in enumerate(['Original','Top -2px','Top +2px','Bottom -2px','Bottom +2px']):ax[0,c].set_title(t,fontsize=9)
plt.tight_layout();plt.savefig(D/'phase4_small_shift_visual.png',dpi=125);plt.close()
